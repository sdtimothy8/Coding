__author__ = 'zhangguolei'

RESULT_TYPE_ERROR = 'error'
RESULT_TYPE_SUCCESS = 'success'

DIR_NOT_EXISTS = 'Directory does not exists'
FILE_NOT_EXISTS = 'File does not exists'
FILE_EXISTS = 'File already exists'
ADD_SUCCESS = 'Successfully added'
DELETE_SUCCESS = 'Successfully deleted'
PATH_CONTAIN_ILLEGAL_CHAR = "Path contains illegal characters"
FILE_SIZE_OUT = "File size is out of range"
