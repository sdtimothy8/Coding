__author__ = 'zhangguolei'


def getResult(type, message):
    """
    get result value
    :param type:
    :param message:
    :return:
    """
    return {"result": {"type": type, "message": message}}
