# coding=utf-8
__author__ = 'zhuysh@inspur.com'

ID = 'id'
ALIAS = 'alias'
IP = 'ip'
PORT = 'port'
STATUS = 'status'
TOKEN = 'token'
CONNENT_TIME = 'connentTime'
NODE_TOKEN = 'UNICORN-AGENT-TOKEN'
RUNNING = 'RUNNING'


NODE = {ID: '',
        ALIAS: '',
        IP: '',
        PORT: 0,
        STATUS: 'RUNNING',
        TOKEN: NODE_TOKEN,
        CONNENT_TIME: CONNENT_TIME}

REGISTER_SUCESS = 'SUCESS'
NODE_STATUS = 'NODE_STATUS'
