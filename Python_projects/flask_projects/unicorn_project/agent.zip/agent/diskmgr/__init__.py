# this is the module for disk management.
# At first, we just support disk capacity query feature.
# by shaomingwu@inspur.com
