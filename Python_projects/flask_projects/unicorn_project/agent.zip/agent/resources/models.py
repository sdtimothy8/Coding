from django.db import models


# Create your models here.
class NetIOInfo(models.Model):
    total = models.FloatField()
