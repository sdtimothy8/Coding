# __author__ = 'root'
import subprocess
import os
import pika
import json
from string import strip
import time
import sys
import traceback
import psutil
# import logging
# from ksmp import settings
# from ksmp import logger
# from agent.utils import getServerInfo

def getAllPortsInfo():
    """
    return:the process list  include basic information
    """
    result_list = []
    #Todo: flag, node_id = getAgentId()
    status = ""
    cmd = 'netstat -ntul4'
    res = os.popen(cmd).readlines()
    for line in res[2:len(res)]:
        ps_line = line.split()
        portType = ps_line[0]
        # port status
        if portType == "tcp":
            status = ps_line[5]
        else:
            status = ""
        # port Id
        portIDInfo = ps_line[3].split(':')
        portID = portIDInfo[1]
        # construct the port dict
        pt_dict = {
                'portType': ps_line[0],
                'portID': portID,
                'status': status
        }
        result_list.append(pt_dict)

    return result_list

def getConditionalPortsInfo( portType, portID, status):
    """
    return:the process list based on the search condition
    """
    result_list = []
    #Todo: flag, node_id = getAgentId()
    status = ""
    cmd = "netstat -ntul4| sed -n '3,$p'"
    if portType == "tcp":
        cmd = "netstat -ntl4|sed -n '3,$p'"
    elif portType == "udp":
        cmd = "netstat -nul4|sed -n '3,$p'"
    else:
        pass

    # filter by portID
    if len(portID) != 0:
        cmd = cmd + " |awk '/:%s/{print $0}'" %portID

    # filter by status
    if len(status) != 0:
        cmd = cmd + " |awk '/%s/{print $0}'" %status
    
    print cmd
    res = os.popen(cmd).readlines()
    for line in res:
        ps_line = line.split()
        portType = ps_line[0]
        # port status
        if portType == "tcp":
            status = ps_line[5]
        else:
            status = ""
        # port Id
        portIDInfo = ps_line[3].split(':')
        portID = portIDInfo[1]
        # construct the port dict
        pt_dict = {
                'portType': ps_line[0],
                'portID': portID,
                'status': status
        }
        result_list.append(pt_dict)

    return result_list

# if __name__ == "__main__":
#    flag, ip = getRabbitmqIp()
#    print ip
